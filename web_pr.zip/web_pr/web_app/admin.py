from django.contrib import admin
from .models import *

# Register your models here.

admin.site.register(Project)
admin.site.register(TodoRed)
admin.site.register(TodoYellow)
admin.site.register(TodoGreen)
admin.site.register(SnakeHighcore)
